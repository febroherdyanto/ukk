Webiste Ini dibuat untuk memenuhi persyaratan Kelulusan SMK pada Tahun 2016.
Yaitu Ujian Praktek Kejuruan RPL (Rekayasa Perangkat Lunak).


Webiste ini masih menggunakan Koneksi Database MySQL. Jadi jika ingin membuka web ini menggunakan PHP versi 5.5 kebawah..

File Koneksi Database :
     * config/koneksi.php
Database :
     * ukk.sql
Login Admin :
     * Username = a
     * Password = a

Terima Kasih.. Febro Herdyanto..